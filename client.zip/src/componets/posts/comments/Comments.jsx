import "./comment.scss";


const Comments = () => {
  return (
    <div>Comments</div>
  )
}

export default Comments