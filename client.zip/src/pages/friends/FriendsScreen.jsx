import "./friends.scss"

const FriendsScreen = () => {
  return (
    <div>FriendsScreen</div>
  )
}

export default FriendsScreen