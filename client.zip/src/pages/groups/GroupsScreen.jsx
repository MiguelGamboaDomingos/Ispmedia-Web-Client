import "./groups.scss"

const GroupsScreen = () => {
  return (
    <div>GroupsScreen</div>
  )
}

export default GroupsScreen