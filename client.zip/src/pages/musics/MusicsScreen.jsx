import "./musics.scss"

const MusicsScreen = () => {
  return (
    <div>MusicsScreen</div>
  )
}

export default MusicsScreen