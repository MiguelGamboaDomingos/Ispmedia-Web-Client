import "./playlists.scss"
const PlaylistsScreen = () => {
  return (
    <div>PlaylistsScreen</div>
  )
}

export default PlaylistsScreen