import "./profile.scss"

const ProfileScreen = () => {
  return (
    <div>Profile</div>
  )
}

export default ProfileScreen