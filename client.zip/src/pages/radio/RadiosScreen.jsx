import"./radios.scss"

const RadiosScreen = () => {
  return (
    <div>RadiosScreen</div>
  )
}

export default RadiosScreen