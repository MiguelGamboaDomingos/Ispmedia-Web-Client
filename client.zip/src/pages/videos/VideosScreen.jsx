import "./videos.scss"

const VideosScreen = () => {
  return (
    <div>VideosScreen</div>
  )
}

export default VideosScreen